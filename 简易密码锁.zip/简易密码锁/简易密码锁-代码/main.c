//@简易密码锁（预设密码（1145），输入正确，则LED全亮）
//按键S1~S9,分别代表1~9,S10代表0，S11是确认键，S12是清除一位键，S13是全部清除键
#include <REGX52.H>
#include "Delay.h"
#include "LCD1602.h"
#include "MatrixKey.h"
unsigned char KeyNum;
unsigned int Password,Count;
void main()
{
	LCD_Init();
	LCD_ShowString(1,1,"Password:");
	P2=0xFF;//由于按键冲突，刚打开开关，部分LED会闪亮，因此用P2=0xFF来进行灭灯
	while(1)
	{	
		KeyNum=MatrixKey();//在MatrixKey()中已进行按键的阻塞延时消抖
		if(KeyNum!=0)
		{
			if(KeyNum<=10) //如果按键S1~S10按键按下，输入密码
			{
				if(Count<4)
				{	
					Password=Password*10;         //密码左移一位
					Password=Password+KeyNum%10;  //获取一位密码
					Count++;
				}
				LCD_ShowNum(2,1,Password,4);
				P2=0xFF;//输入密码时，防止灯乱闪
			}
			if(KeyNum==11)
			{
				LCD_ShowString(1,14,"   ");//将上一次的“OK”或“ERR”的·结果清零
				if(Password==1145)
				{
					LCD_ShowString(1,14,"OK");
					Password=0;
					Count=0;
					LCD_ShowNum(2,1,Password,4);
					P2=0x00;//如果密码正确，则灯全亮
				}
				else
				{
					LCD_ShowString(1,14,"ERR");
					Password=0;
					Count=0;
					LCD_ShowNum(2,1,Password,4);
					P2=0xFF;//防止灯乱闪
				}
			}
			if(KeyNum==12)//清除一位
			{
				Password=Password/10;
				Count--;
				LCD_ShowNum(2,1,Password,4);
				P2=0xFF;//防止灯乱闪
			}
			if(KeyNum==13)//全部清除
			{
				Password=0;
				Count=0;
				LCD_ShowNum(2,1,Password,4);
				P2=0xFF;//防止灯乱闪
			}
		}
	}
}
