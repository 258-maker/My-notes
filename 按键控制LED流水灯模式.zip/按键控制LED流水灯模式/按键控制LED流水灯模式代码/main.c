/**
  * @brief  按键控制LED流水灯模式，按P3_2，初始向右，按下向左，再按下向右
  * @param  无
  * @retval 无
  */
#include <REGX52.H>
#include "Timer0.h"
#include "exti0.h"
#include "delay100us.h"
#include <INTRINS.H>//函数库
unsigned char key_flag=0;//定义全局变量，key_flag==1时，说明按下按键过
unsigned char startup=0;//定义全局变量，0-向右，1-向左
void main()
{
	P2=0xFE;
	Timer0_Init();
	EXTI0_Init();
	while(1)
	{
		if(key_flag == 1)
        {
            // 再次确认按键松手，双重消抖
            if(P3_2 == 1)
            {
                key_flag = 0;
                startup=!startup;
            }
        }
	}
}

void Timer0_Routine() interrupt 1
{
	static unsigned int T0Count;//static保证每一次执行这个函数时T0Count不清零
	TL0 = 0x66;				//设置定时初始值
	TH0 = 0xFC;				//设置定时初始值
	T0Count++;
	if(T0Count>=500)
	{
		T0Count=0;
		if(startup==0){P2=_crol_(P2,1);}//_crol_为左移函数
		if(startup==1){P2=_cror_(P2,1);}//_crol_为右移函数
	}

}
void My_EXTI0() interrupt 0
{
	//短消抖
	Delay100us();
	Delay100us();
	if(P3_2==0)
	{
		key_flag = 1;
	}
}