/**
  * @brief  初始化INT0
  * @param  无
  * @retval 无
  */
#include <REGX52.H>
void EXTI0_Init(void)
{
	IT0=1;
	EX0=1;
	EA=1;
}