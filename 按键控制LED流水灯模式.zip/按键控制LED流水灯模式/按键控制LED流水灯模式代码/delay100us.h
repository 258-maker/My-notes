#ifndef __DELAY100US_H__
#define __DELAY100US_H__
void Delay100us(void);
#endif