#ifndef __EXTI0_H__
#define __EXTI0_H__
void EXTI0_Init(void);
#endif