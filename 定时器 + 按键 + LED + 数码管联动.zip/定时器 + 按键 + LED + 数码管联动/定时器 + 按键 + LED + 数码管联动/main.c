/**
  * @brief  按键控制计数启停（按下P3_2开始计数，再按一下停止计数），
  *			数码管显示计数（从0~99），
  *			LED指示计数状态（P2_7即第八个LED，亮说明计数进行，不亮说明计数停止）
  * @param  无
  * @retval 无
  */
#include <REGX52.H>
#include "delay100us.h"
#include "nixie.h"
#include "time0.h"
#include "exti0.h"
unsigned char key_flag=0;//定义全局变量，key_flag==1时，说明按下按键过
unsigned char judgment=0;//定义全局变量，0-扫描十位，1-扫描个位
unsigned char startup=0;//定义全局变量，0-计数暂停，1-计数运行
void main()
{
	Time0_Init();//进行定时器0初始化
	EXTI0_Init();//外部中断0初始化
	P2_7=1;//初始化P2_7为高电平：LED灭（计数暂停）
	while(1)
	{
		if(key_flag == 1)
        {
            // 再次确认按键松手，双重消抖
            if(P3_2 == 1)
            {
                key_flag = 0;
                startup=!startup;
                P2_7=!startup; //LED同步计数状态
            }
        }
	}
}

/**
  * @brief  中断响应函数，当startup==1时，进行个位十位分离，并逐一在数码管上显示
  * @param  无
  * @retval 无
  */
void My_Time0() interrupt 1
{
	static unsigned int cnt=0; //用来计时
	static unsigned int count=0;//用来计数
	TH0=0xFC;
	TL0=0x66;
	if(startup==1)
	{
		cnt++;
		if(cnt==1000)
		{
			cnt=0;
			count++;
			if(count==100)
			{
				count=0;
			}
		}
	}
	
	//在0~99范围内的数字，/10获得十位上的数字，%10获得个位上的数字，且每隔1ms刷新一次，保证显示不闪
	if(judgment==0)
	{
		Nixie(1,count/10);
		judgment=1;
	}
	else
	{
		Nixie(2,count%10);
		judgment=0;
	}
}

void My_EXTI0() interrupt 0
{
	//短消抖
	Delay100us();
	Delay100us();
	if(P3_2==0)
	{
		key_flag = 1;
	}
}