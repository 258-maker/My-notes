/**
  * @brief  初始化TIM0，定时1ms
  * @param  无
  * @retval 无
  */
#include <REGX52.H>
#include "nixie.h"
void Time0_Init(void)
{
	TMOD |=0x01;
	TMOD &=0xF0;
	TH0=0xFC;
	TL0=0x66;
	TR0=1;
	ET0=1;
	EA=1;
}
