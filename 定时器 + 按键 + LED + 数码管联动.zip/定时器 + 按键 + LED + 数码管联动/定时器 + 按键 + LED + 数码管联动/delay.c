/**
  * @brief  延时函数，延时100us
  * @param  无
  * @retval 无
  */
#include <REGX52.H>
void Delay(unsigned int xms)	//@11.0592MHz
{
	unsigned char data i, j;
	while(xms)
	{
		i = 11;
		j = 190;
		do
		{
			while (--j);
		} while (--i);
		xms--;
	}
}

