//《鸟之诗》
#include <REGX52.H>
#include "Delay.h"
#include "Timer0.h"

//蜂鸣器端口定义
sbit Buzzer = P2^5;

//播放速度，以四分音符为基准
#define SPEED 500

//音符与索引对应表————P：休止符，L：低音，M：中音，H：高音，G：超高音，下划线：升半音符号#
#define P	0

#define L1	1
#define L1_	2
#define L2	3
#define L2_	4
#define L3	5
#define L4	6
#define L4_	7
#define L5	8
#define L5_	9
#define L6	10
#define L6_	11
#define L7	12

#define M1	13
#define M1_	14
#define M2	15
#define M2_	16
#define M3	17
#define M4	18
#define M4_	19
#define M5	20
#define M5_	21
#define M6	22
#define M6_	23
#define M7	24

#define H1	25
#define H1_	26
#define H2	27
#define H2_	28
#define H3	29
#define H4	30
#define H4_	31
#define H5	32
#define H5_	33
#define H6	34
#define H6_	35
#define H7	36

#define G1	37
#define G1_	38
#define G2	39
#define G2_	40
#define G3	41
#define G4	42
#define G4_	43
#define G5	44
#define G5_	45
#define G6	46
#define G6_	47
#define G7	48

//索引与频率对照表
unsigned int FreqTable[]={
	0,
	63628,63731,63835,63928,64021,64103,64185,64260,64331,64400,64463,64524,
	64580,64633,64684,64732,64777,64820,64860,64898,64934,64968,65000,65030,
	65058,65085,65110,65134,65157,65178,65191,65217,65235,65252,65268,65283,
	65297,65310,65323,65335,65346,65357,65367,65377,65385,65394,65402,65409
};

unsigned char FreqSelect,MusicSelect;   //频率选择变量、乐谱播放索引变量

//乐谱
code unsigned   char Music[]={
	//音符,时值,
	
    //1
	P,4,
    P,4,
    P,2,
    H5,2,
    H6,2,
    G1,2,
    
    H7,4+4,
    P,2,
    H5,2,
    H6,2,
    G1,2,
    
    G2,4+4,
    P,2,
    H5,2,
    H6,2,
    G1,2,
    
    G5,4+4+4,
    P,2,
    G4,2,
    
    G3,4+4,
    P,2,
    H5,2,
    H6,2,
    G1,2,
    
    H7,4+4,
    P,2,
    H5,2,
    H6,2,
    G1,2,
    
    G2,4+4,
    P,2,
    H3,2,
    H5,2,
    H7,2,
    
    H6,4+4+4+4,
 
	//2
    P,4,
    P,2,
    L6,4,
    L7,2,
    M1,2,
    M5,2,
    
    M3,4,
    M3,2,
    M2,1,
    M3,1+4+4,
    
	//3
    P,4,
    M2,2,
    M3,2,
    M5,2,
    M1,2,
    L7,2,
    M1,2,
    
    L7,4,
    L7,2,
    L6,1,
    L3,1+4+4,
    
    
    P,4,
    P,2,
    L6,4,
    L7,2,
    M1,2,
    M5,2,
    
    M3,4,
    M3,2,
    M2,1,
    M3,1+4+4,
    
	//4
    P,4,
    M2,2,
    M3,2,
    M5,2,
    M3,2,
    M5,2,
    H1,2,
    
    M7,3,
    M6,1+2,
    M3,2+4,
    P,2,
    M2,2,
    
    M3,4,
    M5,4,
    M6,4,
    M7,4,
    
    M3,4,
    M3,2,
    M2,1,
    M3,1+4+4,
    
	//5
    P,4,
    M2,2,
    M3,2,
    M5,2,
    M1,2,
    L7,2,
    M1,2,
    
    L7,4,
    L7,2,
    L6,1,
    L3,1+4+4,
    
    
    P,4,
    P,2,
    L6,4,
    L7,2,
    M1,2,
    M5,2,
    
    M3,4,
    M3,2,
    M2,1,
    M3,1+4+4,
    
	//6
    P,4,
    M2,2,
    M3,2,
    M5,2,
    M3,2,
    M5,2,
    H1,2,
    
    M7,4+4+4+2,
    M6,2,
    
    M6,4+4,
    P,4,
    M6,4,
    
    M7,4+4+4+2,
    M6,2,
    
    M6,4+4+4+4,
	
	P,4,
	
	0xFF    //终止标志
};                     
                      
void main()
{
	Buzzer=1;
    Timer0_Init();
	while(1)
	{
        if(Music[MusicSelect]!=0xFF)   //如果不是停止标志位
        {
            FreqSelect = Music[MusicSelect];   //选择音符对应的频率
            MusicSelect++;
            Delay(SPEED/4*Music[MusicSelect]);   //选择音符对应的时值
            MusicSelect++;
            TR0=0;
            Delay(5);   //音符间短暂停顿
            TR0=1;
        }
        else   //如果是停止标志位
        {
            TR0=0;
			Buzzer=1;
            while(1);
        }
	}
}


// 定时器0中断函数，用于产生蜂鸣器频率
void Timer0_Routine() interrupt 1     
{
    if(FreqTable[FreqSelect])   //如果不是休止符
        {
			/*取对应频率值的重装载值到定时器*/
            TL0 = FreqTable[FreqSelect]%256;				//设置定时初始值
            TH0 = FreqTable[FreqSelect]/256;				//设置定时初始值
            Buzzer=!Buzzer;   //翻转蜂鸣器IO口
        }            
}