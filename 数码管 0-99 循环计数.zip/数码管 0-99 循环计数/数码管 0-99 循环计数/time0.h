#ifndef __TIME0_H__
#define __TIME0_H__
void Time0_Init(void);
#endif