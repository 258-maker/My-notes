/**
  * @brief  延时函数，延时100us
  * @param  无
  * @retval 无
  */
#include <REGX52.H>
void Delay100us(void)	//@11.0592MHz
{
	unsigned char data i, j;
	i = 2;
	j = 15;
	do
	{
		while (--j);
	} while (--i);
}
