#ifndef __DELAY_H__
#define __DELAY_H__
void Delay100us(void);
#endif